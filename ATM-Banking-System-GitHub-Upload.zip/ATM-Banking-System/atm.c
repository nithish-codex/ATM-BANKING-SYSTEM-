#include <stdio.h>

int main(void) {
    int pin, choice;
    double balance = 5000.00;
    double amount;

    printf("===== ATM BANKING SYSTEM =====\n");
    printf("Enter ATM PIN: ");
    if (scanf("%d", &pin) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    if (pin != 1234) {
        printf("Invalid PIN!\n");
        return 0;
    }

    do {
        printf("\n===== MAIN MENU =====\n");
        printf("1. Check Balance\n");
        printf("2. Deposit Money\n");
        printf("3. Withdraw Money\n");
        printf("4. My Profile / Resume\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            return 1;
        }

        switch (choice) {
            case 1:
                printf("Available balance: Rs. %.2f\n", balance);
                break;

            case 2:
                printf("Enter deposit amount: Rs. ");
                if (scanf("%lf", &amount) != 1) {
                    printf("Invalid amount.\n");
                    return 1;
                }
                if (amount > 0) {
                    balance += amount;
                    printf("Deposit successful.\n");
                    printf("New balance: Rs. %.2f\n", balance);
                } else {
                    printf("Enter an amount greater than zero.\n");
                }
                break;

            case 3:
                printf("Enter withdrawal amount: Rs. ");
                if (scanf("%lf", &amount) != 1) {
                    printf("Invalid amount.\n");
                    return 1;
                }
                if (amount <= 0) {
                    printf("Enter an amount greater than zero.\n");
                } else if (amount > balance) {
                    printf("Insufficient balance.\n");
                } else {
                    balance -= amount;
                    printf("Please collect your cash.\n");
                    printf("Remaining balance: Rs. %.2f\n", balance);
                }
                break;

            case 4:
                printf("\n===== STUDENT PROFILE =====\n");
                printf("Name: Nithish\n");
                printf("Course: B.Tech\n");
                printf("Branch: Computer Science and Engineering (Data Science)\n");
                printf("College: Loyola\n");
                printf("Skill: C Programming (Beginner)\n");
                printf("Project: ATM Banking System using C\n");
                printf("Career Interest: Software Development\n");
                break;

            case 5:
                printf("Thank you for using the ATM Banking System.\n");
                break;

            default:
                printf("Invalid choice. Please select 1 to 5.\n");
        }
    } while (choice != 5);

    return 0;
}
