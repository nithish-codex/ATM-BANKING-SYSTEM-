# ATM Banking System Using C

A beginner-level, menu-driven ATM simulation built with the C programming language.

## Features
- PIN verification (demo PIN: `1234`)
- Check account balance
- Deposit money
- Withdraw money with balance validation
- View student profile / resume summary
- Menu-driven interface

## Concepts used
- `printf()` and `scanf()`
- `if-else` statements
- `switch` statement
- `do-while` loop
- Variables and arithmetic operations

## How to compile and run

Using GCC:

```bash
gcc atm.c -o atm
./atm
```

On Windows:

```bash
gcc atm.c -o atm.exe
atm.exe
```

## Demo information
- Starting balance: Rs. 5000.00
- Demo PIN: `1234`

## Important note
This is an educational simulation only. It does not connect to a real bank, use a real ATM card, or store real account information. The PIN and balance are hard-coded and reset each time the program runs.
